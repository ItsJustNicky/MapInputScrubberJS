const map = L.map('map',
{
    center: [-29.50, 145],
    zoom: 3.5
    
});
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);


const search = document.getElementById("search");
function hasWhiteSpace(s) {
  return s.indexOf(' ') >= 0;
}
function isNumber(char) {
  return /^\d$/.test(char);
}

function writeToJson(){

}
function popupSpawn(){
  
    console.log("Pushed button");
    var coords = prompt("Enter your coordinates");
    let long ="<NULL>";
    let lat ="<NULL>";
    const ERROR = "ERROR! Input text is not a valid coordinate";
    if(isNumber(coords[0])){
      document.getElementById("text").innerText=coords;
    }else{
      document.getElementById("text").innerText=ERROR;
    }
    console.log(coords);
}
